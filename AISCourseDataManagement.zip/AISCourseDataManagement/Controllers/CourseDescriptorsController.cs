﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AISCourseDataManagement.Models;

namespace AISCourseDataManagement.Controllers
{
    public class CourseDescriptorsController : Controller
    {
        private readonly ApplicationContext _context;

        public CourseDescriptorsController(ApplicationContext context)
        {
            _context = context;
        }

        // GET: CourseDescriptors
        public async Task<IActionResult> Index()
        {
            return View(await _context.courseDescriptors.ToListAsync());
        }

        // GET: CourseDescriptors/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var courseDescriptor = await _context.courseDescriptors
                .FirstOrDefaultAsync(m => m.CourseDescriptorID == id);
            if (courseDescriptor == null)
            {
                return NotFound();
            }

            return View(courseDescriptor);
        }

        // GET: CourseDescriptors/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: CourseDescriptors/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CourseDescriptorID,Programme,CourseCode,Version,CourseTitle,NZQFLevel,Credits,Prerequisites,Corequisites,Restrictions,CourseAim,DeliveryMethods,DateLastUpdated,LearningOutcomes,TeachingHours,SelfDirectedHours,TotalHours,TotalWeeks,Content")] CourseDescriptor courseDescriptor)
        {
            if (ModelState.IsValid)
            {
                _context.Add(courseDescriptor);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(courseDescriptor);
        }

        // GET: CourseDescriptors/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var courseDescriptor = await _context.courseDescriptors.FindAsync(id);
            if (courseDescriptor == null)
            {
                return NotFound();
            }
            return View(courseDescriptor);
        }

        // POST: CourseDescriptors/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("CourseDescriptorID,Programme,CourseCode,Version,CourseTitle,NZQFLevel,Credits,Prerequisites,Corequisites,Restrictions,CourseAim,DeliveryMethods,DateLastUpdated,LearningOutcomes,TeachingHours,SelfDirectedHours,TotalHours,TotalWeeks,Content")] CourseDescriptor courseDescriptor)
        {
            if (id != courseDescriptor.CourseDescriptorID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(courseDescriptor);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CourseDescriptorExists(courseDescriptor.CourseDescriptorID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(courseDescriptor);
        }

        // GET: CourseDescriptors/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var courseDescriptor = await _context.courseDescriptors
                .FirstOrDefaultAsync(m => m.CourseDescriptorID == id);
            if (courseDescriptor == null)
            {
                return NotFound();
            }

            return View(courseDescriptor);
        }

        // POST: CourseDescriptors/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var courseDescriptor = await _context.courseDescriptors.FindAsync(id);
            _context.courseDescriptors.Remove(courseDescriptor);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CourseDescriptorExists(string id)
        {
            return _context.courseDescriptors.Any(e => e.CourseDescriptorID == id);
        }
    }
}
