﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace AISCourseDataManagement.Migrations
{
    public partial class v1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "courseDescriptors",
                columns: table => new
                {
                    CourseDescriptorID = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Programme = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CourseCode = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Version = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CourseTitle = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    NZQFLevel = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Credits = table.Column<int>(type: "int", nullable: false),
                    Prerequisites = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Corequisites = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Restrictions = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CourseAim = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DeliveryMethods = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DateLastUpdated = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LearningOutcomes = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TeachingHours = table.Column<int>(type: "int", nullable: false),
                    SelfDirectedHours = table.Column<int>(type: "int", nullable: false),
                    TotalHours = table.Column<int>(type: "int", nullable: false),
                    TotalWeeks = table.Column<int>(type: "int", nullable: false),
                    Content = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_courseDescriptors", x => x.CourseDescriptorID);
                });

            migrationBuilder.CreateTable(
                name: "externalModerations",
                columns: table => new
                {
                    CourseID = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    CourseName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    NameOfExternalModerator = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DatePassedToExternalModerator = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DateOfExternalmoderatorReport = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DateOfResponseToReport = table.Column<DateTime>(type: "datetime2", nullable: false),
                    NextDueDateForExternalModeration = table.Column<DateTime>(type: "datetime2", nullable: false),
                    SendEmailNotificationTo = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_externalModerations", x => x.CourseID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "courseDescriptors");

            migrationBuilder.DropTable(
                name: "externalModerations");
        }
    }
}
