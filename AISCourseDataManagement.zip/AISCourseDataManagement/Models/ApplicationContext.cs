﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AISCourseDataManagement.Models
{
    public class ApplicationContext : DbContext
    {
        public ApplicationContext(DbContextOptions<ApplicationContext> options) : base(options)
        { }
        public DbSet<ExternalModeration> externalModerations { get; set; }
        public DbSet<CourseDescriptor> courseDescriptors { get; set; }

    
    }
}
